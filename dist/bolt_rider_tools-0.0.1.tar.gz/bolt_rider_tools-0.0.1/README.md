The first part of one exercise program to make easier life to delivery riders.
It needs more improvements, like one scraper of the best delivery zones, but I
need to show to one friend now.
